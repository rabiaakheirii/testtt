#include "fit/tbeta_penalty.hpp"
#include <algorithm>

namespace bwmu {

    // Published PHENIX T(beta_s) relation — DESCENDING line.
    // Source: PHENIX PRC 69, 034909 (2004).
    //
    //   beta_s = 0.60  ->  T = 108 MeV
    //   slope  = -200 MeV per unit beta_s
    //
    // Below beta_s = 0.50 the relation is uncertain, so we
    // continue the linear trend but with a mild slope.
    double T_exp_of_beta(double beta_s) {
        constexpr double T_ref   = 0.108;   // 108 MeV
        constexpr double beta_ref = 0.60;
        constexpr double slope    = -0.200;  // 200 MeV per unit

        double T = T_ref + slope * (beta_s - beta_ref);

        // Floor to keep T physical
        return std::max(T, 0.085);
    }

    double tbeta_penalty(double T, double beta_s, double lambda) {
        const double d = T - T_exp_of_beta(beta_s);
        return lambda * d * d;
    }

} // namespace bwmu
